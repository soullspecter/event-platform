import { Body, Controller, Delete, Get, Param, ParseIntPipe, Patch, Post, Req, UseGuards } from '@nestjs/common';
import type { FastifyRequest } from 'fastify';

import { JwtAuthGuard } from '../../auth/jwt/jwt-auth.guard';
import { Roles } from '../../../common/decorators/roles.decorator';
import { RolesGuard } from '../../../common/guards/roles.guard';

import { SaveEventDto } from './dto/save-event.dto';
import { EventsService } from './events.service';

type AuthenticatedRequest = FastifyRequest & {
    user: { userId: number; email: string; roles: string[] };
};

@Controller('events')
export class EventsController {
    constructor(private readonly eventsService: EventsService) {}

    @Post('drafts')
    @UseGuards(JwtAuthGuard, RolesGuard)
    @Roles('admin')
    createDraft(@Req() req: AuthenticatedRequest, @Body() dto: SaveEventDto) {
        return this.eventsService.createDraft(req.user.userId, dto);
    }

    @Post(':id/publish')
    @UseGuards(JwtAuthGuard, RolesGuard)
    @Roles('admin')
    publish(@Param('id', ParseIntPipe) id: number) {
        return this.eventsService.publish(id);
    }

    @Patch(':id/draft')
    @UseGuards(JwtAuthGuard, RolesGuard)
    @Roles('admin')
    updateDraft(@Param('id', ParseIntPipe) id: number, @Body() dto: SaveEventDto) {
        return this.eventsService.updateEvent(id, dto);
    }

    @Get('drafts')
    @UseGuards(JwtAuthGuard, RolesGuard)
    @Roles('admin')
    findDrafts() {
        return this.eventsService.findDrafts();
    }

    @Get('mine')
    @UseGuards(JwtAuthGuard)
    findMine(@Req() req: AuthenticatedRequest) {
        return this.eventsService.findMine(req.user.userId);
    }

    @Get(':id/manage')
    @UseGuards(JwtAuthGuard, RolesGuard)
    @Roles('admin')
    findForManagement(@Param('id', ParseIntPipe) id: number) {
        return this.eventsService.findForManagement(id);
    }

    @Get()
    findPublished() {
        return this.eventsService.findPublished();
    }

    @Get(':id')
    findPublishedById(@Param('id', ParseIntPipe) id: number) {
        return this.eventsService.findPublishedById(id);
    }

    @Delete(':id')
    @UseGuards(JwtAuthGuard, RolesGuard)
    @Roles('admin')
    remove(@Param('id', ParseIntPipe) id: number) {
        return this.eventsService.remove(id);
    }
}
